/*

import 'googlesheets.dart';

class SheetsColumn {
  static final name = "name";
  static final last = "last";
  static final email = "email";
  static final password = "password";
  static final phoneNum = "phoneNum";
  static final skills = "skills";
  static final location = "location";
  static final theIcon = "theIcon";
  static final education = "education";

  static List<String> getColumn() => [
        name,
        last,
        email,
        password,
        phoneNum,
        skills,
        location,
        theIcon,
        education
      ];
}

class User {
  final String? name,
      last,
      email,
      password,
      theIcon,
      location,
      education,
      phoneNum,
      skills;

  User(
      {required this.name,
      required this.last,
      required this.email,
      required this.location,
      required this.education,
      required this.phoneNum,
      required this.skills,
      required this.theIcon,
      required this.password});

  /// newUser = user.copy(name: new name);
  User copy(
          {String? name,
          last,
          email,
          location,
          education,
          phoneNum,
          skills,
          theIcon,
          password}) =>
      User(
          name: name ?? this.name,
          last: last ?? this.last,
          email: email ?? this.email,
          location: location ?? this.location,
          education: education ?? this.education,
          phoneNum: phoneNum ?? this.phoneNum,
          skills: skills ?? this.skills,
          theIcon: theIcon ?? this.theIcon,
          password: password ?? this.password);

  static User fromJson(Map<String, dynamic> json) => User(
        //name: jsonDecode(json[SheetsColumn.name])
        // solving problems of type
        name: json[SheetsColumn.name],
        last: json[SheetsColumn.last],
        email: json[SheetsColumn.email],
        password: json[SheetsColumn.password],
        phoneNum: json[SheetsColumn.phoneNum],
        skills: json[SheetsColumn.skills],
        location: json[SheetsColumn.location],
        theIcon: json[SheetsColumn.theIcon],
        education: json[SheetsColumn.education],
      );

  Map<String, dynamic> toJson() {
    return {
      SheetsColumn.name: name,
      SheetsColumn.last: last,
      SheetsColumn.email: email,
      SheetsColumn.password: password,
      SheetsColumn.phoneNum: phoneNum,
      SheetsColumn.skills: skills,
      SheetsColumn.location: location,
      SheetsColumn.theIcon: theIcon,
      SheetsColumn.education: education,
    };
  }
}
 */
