/*
import 'package:flutter/material.dart';

import 'DataBase/jobModel.dart';

class JobView extends StatelessWidget {
  JobView({Key? key}) : super(key: key);
  final List posts = [
    JobOffer(
        title: "python",
        Job_location: "מרכז",
        job_type: "Part-time",
        Job_description:
            "We are looking for a detail-oriented marketing coordinator to assist with various marketing campaigns and initiatives. The ideal candidate should have strong communication skills and be familiar with social media platforms and analytics tools.",
        Job_requirements:
            "Bachelor's degree in Marketing or related field, Excellent written and verbal communication skills, Proficiency in social media management, Familiarity with Google Analytics"),
    JobOffer(
        title: "Data Scientist",
        Job_location: "השפלה",
        job_type: "Full-time",
        Job_description:
            "We are seeking a motivated sales representative to drive sales and build relationships with potential clients. The ideal candidate should have a proven track record in sales and excellent interpersonal skills.",
        Job_requirements:
            "Minimum of 2 years of sales experience, Strong negotiation and communication skills, Self-motivated and target-driven"),
    JobOffer(
        title: "machine learning",
        Job_location: "מרכז",
        job_type: "Freelance",
        Job_description:
            "We are looking for a creative and talented graphic designer to create visually appealing designs for various projects. The ideal candidate should have a strong portfolio showcasing their design skills and proficiency in design software.",
        Job_requirements:
            "Bachelor's degree in Graphic Design or related field, Proficiency in Adobe Creative Suite, Strong portfolio demonstrating design abilities"),
    JobOffer(
        title: "java",
        Job_location: "ירושלים",
        job_type: "Full-time",
        Job_description:
            "We are seeking a detail-oriented financial analyst to provide financial analysis and reporting for our organization. The ideal candidate should have strong analytical skills and be proficient in financial modeling and data analysis tools.",
        Job_requirements:
            "Bachelor's degree in Finance or related field, Strong analytical and problem-solving skills, Proficiency in Microsoft Excel and financial modeling"),
    JobOffer(
        title: "python",
        Job_location: "מרכז",
        job_type: "Full-time",
        Job_description:
            "We are looking for a friendly and customer-focused representative to handle customer inquiries and resolve issues. The ideal candidate should have excellent communication skills and the ability to work in a fast-paced environment.",
        Job_requirements:
            "Excellent verbal and written communication skills, Strong problem-solving abilities, Previous customer service experience is a plus"),
    JobOffer(
        title: "Data Scientist",
        Job_location: "דרום",
        job_type: "Full-time",
        Job_description:
            "We are seeking a skilled data scientist to analyze large datasets and generate valuable insights for our organization. The ideal candidate should have a strong background in statistics and machine learning.",
        Job_requirements:
            "Master's degree or higher in Data Science or related field, Proficiency in programming languages such as Python or R, Experience with statistical analysis and machine learning techniques"),
    JobOffer(
        title: "C++",
        Job_location: "מרכז",
        job_type: "Full-time",
        Job_description:
            "We are looking for an experienced HR manager to oversee our HR operations and support the organization's strategic goals. The ideal candidate should have a strong knowledge of HR policies and procedures.",
        Job_requirements:
            "Bachelor's degree in Human Resources or related field, Minimum of 5 years of HR management experience, In-depth understanding of labor laws and regulations"),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        Expanded(
          ///2
          child: ListView.builder(
            itemCount: posts.length,
            itemBuilder: (context, index) {
              return Center(
                child: MySquare(
                  jobOffer: posts[index],
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

class MySquare extends StatelessWidget {
  final JobOffer jobOffer;
  const MySquare({super.key, required this.jobOffer});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.deepPurple[200],
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              offset: Offset(0, 2),
              blurRadius: 4.0,
            ),
          ],
        ),
        color: Colors.deepPurple[200],
        child: Expanded(
          child: Column(
            children: [
              Text('Title: ${jobOffer.title}'),
              Text('Location: ${jobOffer.Job_location}'),
              Text('Job Type: ${jobOffer.job_type}'),
              Text('Description: ${jobOffer.Job_description}'),
              Text('Requirements: ${jobOffer.Job_requirements}'),
            ],
          ),
        ),
      ),
    );
  }
}
 */
