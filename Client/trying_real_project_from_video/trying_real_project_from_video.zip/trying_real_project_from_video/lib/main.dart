import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:trying_real_project_from_video/DataBase/googlesheets.dart';
import 'package:trying_real_project_from_video/tryingvideooffirebase/loginpagenew.dart';
import 'package:trying_real_project_from_video/users_data_base/users.dart';
import 'DataBase/testingProjectOfAfgrommer.dart';
import 'DataBase/trying.dart';
import 'change_notifiers/route_generator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'jobView.dart';

void main() async {
  //await SheetsFlutter.init();
  runApp(AppWidget());
}

class AppWidget extends StatelessWidget {
  AppWidget({super.key});

  final Color _primaryColor = HexColor('#DC54FE');
  final Color _accentColor = HexColor('#8A02AE');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      /*
      home: AfPage(
        user: User(
          name: 'Dori',
          lastName: 'Rozen',
          email: 'dorirozen96@gmail.com',
          location: 'המרכז',
          education: 'B.Sc. in Computer Science',
          phoneNum: '0546396968',
          skills: ['dart', 'c', 'python'],
          myIcon: 'assets/icon3.png',
          password: '1',
        ),
      ), //ProductListPage(),
       */
      home: LoginNew(),
    );
  }
}
/*

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return MaterialApp(
          theme: ThemeData(
            primaryColor: _primaryColor,
            scaffoldBackgroundColor: Colors.grey.shade100,
            colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.grey)
                .copyWith(secondary: _accentColor),
            primarySwatch: Colors.blue,
            textTheme: Typography.englishLike2018.apply(fontSizeFactor: 1.sp),
          ),
          title: 'Job Finder App',
          debugShowCheckedModeBanner: false,
          initialRoute: '/',
          onGenerateRoute: RouteGenerator.generateRoute,
        );
      },
    );
  }
}
 */
