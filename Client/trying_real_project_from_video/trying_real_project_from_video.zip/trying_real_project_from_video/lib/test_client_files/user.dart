/*
import 'dart:convert';

List<User> userFromJson(String str) =>
    List<User>.from(json.decode(str).map((x) => User.fromJson(x)));

String userToJson(List<User> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class User {
  User({
    this.name,
    this.avatar,
    this.id,
    this.username,
    this.email,
    this.role,
  });

  String? name, email, role;
  String? avatar;
  String? id;
  String? username;

  factory User.fromJson(Map<String, dynamic> json) => User(
        username: json["username"],
        avatar: json["avatar"],
        email: json["email"],
        role: json["role"],
        /*
        qualifications: json["qualifications"] != null
            ? List<Qualification>.from(
                json["qualifications"].map((x) => Qualification.fromJson(x)))
            : [],
         */
      );

  Map<String, dynamic> toJson() =>
      {"username": username, "avatar": avatar, "email": email, "role": role};
}
 */
