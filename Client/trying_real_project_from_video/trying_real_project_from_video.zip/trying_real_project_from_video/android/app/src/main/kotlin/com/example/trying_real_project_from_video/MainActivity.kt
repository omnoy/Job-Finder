package com.example.trying_real_project_from_video

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
