///________________________ Content_onbording_constant_file__________________
const String gif1 = "assets/gif1.gif";
const String send_gif = "assets/send_gif.gif";
const String gif3 = "assets/gif3.gif";

///________________________ Home __________________
const String profile_1 = "assets/profile_1.png";
