///_______________ splash scren____________________
const String flex = "Marvel team";
const String easyFindjob = "Easy job\nsolution finder";
const String flex_Sub =
    "Explore over 30,000 available job\nroles & boost your career now.";
// const String flex = "Flex jobs";

///_____________________________Onbording___________________________
const String Skip = "Skip";
const String Next = "Next";

///________________________ Content_onbording_constant_file__________________
const String knowledge = "knowledge";
const String Knowledge_sub_tex =
    "We use data to match your job with\na person's skills, experience, & goals.";
const String Training = "Training";
const String Training_sub_tex =
    "Rate those who are a good match,\n& reach out to start a conversation.";
const String Realization = "Realization";
const String Realization_sub_tex =
    "People come to Flex jobs to discover\nopportunities & build their careers. ";

///___________________________ Select_position_screen
const String Get_Started = "Get Started";
const String Select_your_position = "Select your position";

///____________________________ More_option_selected_screen __________________
const String WELLCOME_BACK = "WELLCOME BACK,";
const String JulieBell = "Julie Bell";
const String Find_job_today = "Find job today";
const String Job_title = "Job title";
const String Country = "Country";
const String work_experience = "Work experience";
const String employment = "Employment";
const String salary_from = "Salary from";
const String submit = "Submit";

///_____________________ home page container constant _______________________
const String javaDevloper = "Java Devloper";
const String googleinc = "Google Inc.";
const String fulltime = "Full time";
const String string1 = "\$2400+";
const String day2 = "2 day ago";
const String ux_ui = "UX/UI Designer";
const String weSoftYou = "WeSoftyou";
const String partTime = "Part time";
const String office = "Office";
const String day7 = "7 day ago";
const String backEnd = "Back-End Developer";
const String upSwot = "Upswot";
const String remotely = "Remotely";
const String years2 = "2 years";
const String month = "Month";

///____________ horizontal button constant ________________________
const String designer = "Designer";
const String Canada = "Canada";

///____________ offer container constant ______________________
const String insurance = "Insurance";
const String insurance_Sub = "After probation\nperiod.";
const String english = "English courses";
const String english_Sub = "Compensation\nfor seminars.";
const String experience = "Experience";
const String experience_Sub = "Get experience\nand money.";
const String communication = "communication";
const String communication_Sub = "Quick team\ncommunication.";

///_________________ dashboard page
const String job_Description = "Job Description";
const String job_Description_sub =
    "Working in Flex Jobs — opportunity to develop your skills in special conditions, where the spirit Of a startup. customized prcResses without bureaucracy.";
const String responsibilities = "Responsibilities";
const String developing_2d = "Developing 2D animations";
const String creating_Sub =
    "Creating high quality video and static ads for marketing and brand purposes";
const String Creating_Motion = "Creating motion assets for the ads";
const String upper_intermediate = "Upper-intermediate level of English";
const String what_We_Offer = "What We Offer";
const String apply = "Apply";
