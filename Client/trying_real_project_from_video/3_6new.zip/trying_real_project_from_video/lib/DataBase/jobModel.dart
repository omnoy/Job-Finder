/*
import 'package:flutter/material.dart';

class SheetsColumnForJob {
  static final title = "title";
  static final Job_location = "Job_location";
  static final job_type = "job_type";
  static final Job_description = "Job_description";
  static final Job_requirements = "Job_requirements";

  static List<String> getColumnForJobs() =>
      [title, Job_location, job_type, Job_description, Job_requirements];
}

class JobOffer {
  final String title, Job_location, job_type, Job_description, Job_requirements;

  JobOffer(
      {required this.title,
      required this.Job_location,
      required this.job_type,
      required this.Job_description,
      required this.Job_requirements});

  static final List<JobOffer> jobList = [
    JobOffer(
        title: "python",
        Job_location: "מרכז",
        job_type: "Part-time",
        Job_description:
            "We are looking for a detail-oriented marketing coordinator to assist with various marketing campaigns and initiatives. The ideal candidate should have strong communication skills and be familiar with social media platforms and analytics tools.",
        Job_requirements:
            "Bachelor's degree in Marketing or related field, Excellent written and verbal communication skills, Proficiency in social media management, Familiarity with Google Analytics"),
    JobOffer(
        title: "Data Scientist",
        Job_location: "השפלה",
        job_type: "Full-time",
        Job_description:
            "We are seeking a motivated sales representative to drive sales and build relationships with potential clients. The ideal candidate should have a proven track record in sales and excellent interpersonal skills.",
        Job_requirements:
            "Minimum of 2 years of sales experience, Strong negotiation and communication skills, Self-motivated and target-driven"),
    JobOffer(
        title: "machine learning",
        Job_location: "מרכז",
        job_type: "Freelance",
        Job_description:
            "We are looking for a creative and talented graphic designer to create visually appealing designs for various projects. The ideal candidate should have a strong portfolio showcasing their design skills and proficiency in design software.",
        Job_requirements:
            "Bachelor's degree in Graphic Design or related field, Proficiency in Adobe Creative Suite, Strong portfolio demonstrating design abilities"),
    JobOffer(
        title: "java",
        Job_location: "ירושלים",
        job_type: "Full-time",
        Job_description:
            "We are seeking a detail-oriented financial analyst to provide financial analysis and reporting for our organization. The ideal candidate should have strong analytical skills and be proficient in financial modeling and data analysis tools.",
        Job_requirements:
            "Bachelor's degree in Finance or related field, Strong analytical and problem-solving skills, Proficiency in Microsoft Excel and financial modeling"),
    JobOffer(
        title: "python",
        Job_location: "מרכז",
        job_type: "Full-time",
        Job_description:
            "We are looking for a friendly and customer-focused representative to handle customer inquiries and resolve issues. The ideal candidate should have excellent communication skills and the ability to work in a fast-paced environment.",
        Job_requirements:
            "Excellent verbal and written communication skills, Strong problem-solving abilities, Previous customer service experience is a plus"),
    JobOffer(
        title: "Data Scientist",
        Job_location: "דרום",
        job_type: "Full-time",
        Job_description:
            "We are seeking a skilled data scientist to analyze large datasets and generate valuable insights for our organization. The ideal candidate should have a strong background in statistics and machine learning.",
        Job_requirements:
            "Master's degree or higher in Data Science or related field, Proficiency in programming languages such as Python or R, Experience with statistical analysis and machine learning techniques"),
    JobOffer(
        title: "C++",
        Job_location: "מרכז",
        job_type: "Full-time",
        Job_description:
            "We are looking for an experienced HR manager to oversee our HR operations and support the organization's strategic goals. The ideal candidate should have a strong knowledge of HR policies and procedures.",
        Job_requirements:
            "Bachelor's degree in Human Resources or related field, Minimum of 5 years of HR management experience, In-depth understanding of labor laws and regulations"),
  ];
  static JobOffer fromJson(Map<String, dynamic> json) => JobOffer(
      //name: jsonDecode(json[SheetsColumn.name])
      // solving problems of type
      title: json[SheetsColumnForJob.title],
      Job_location: json[SheetsColumnForJob.Job_location],
      job_type: json[SheetsColumnForJob.job_type],
      Job_description: json[SheetsColumnForJob.Job_description],
      Job_requirements: json[SheetsColumnForJob.Job_requirements]);

  Map<String, dynamic> toJson() {
    return {
      SheetsColumnForJob.title: title,
      SheetsColumnForJob.Job_location: Job_location,
      SheetsColumnForJob.job_type: job_type,
      SheetsColumnForJob.Job_description: Job_description,
      SheetsColumnForJob.Job_requirements: Job_requirements
    };
  }
}

 */
///                       ////////////////////from afProgrammer//////////////////////////
class Job {
  final String title;
  final String address;
  final String timeAgo;
  final String companyLogo;
  final String type;
  final String experienceLevel;
  final String experienceLevelColor;
  bool isMyFav;

  Job(
    this.title,
    this.address,
    this.timeAgo,
    this.companyLogo,
    this.type,
    this.experienceLevel,
    this.experienceLevelColor,
    this.isMyFav,
  );

  factory Job.fromJson(Map<String, dynamic> json) {
    return Job(
      json['title'],
      json['address'],
      json['timeAgo'],
      json['companyLogo'],
      json['type'],
      json['experienceLevel'],
      json['experienceLevelColor'],
      json['isMyFav'],
    );
  }
}
