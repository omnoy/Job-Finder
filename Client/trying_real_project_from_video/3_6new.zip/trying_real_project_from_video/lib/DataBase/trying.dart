/*
import 'package:flutter/material.dart';


import 'jobModel.dart';

class ProductListPage extends StatefulWidget {
  const ProductListPage({Key? key}) : super(key: key);

  @override
  State<ProductListPage> createState() => _ProductListPageState();
}

class _ProductListPageState extends State<ProductListPage> {
  ///tags to show options.
  List<String> categories = [
    'java',
    'python',
    'c++',
    'c',
    'dart',
    'full stack',
    'frontend',
    'backend',
    'machine learning',
    'deep learning'
  ];

  ///initial selected array
  List<String> selectedCategoris = [];
  @override
  Widget build(BuildContext context) {
    ///each time somthing changes it will rebuild and search for the jobs and only contains
    ///what we marked . if nothing so it will add all of them .
    final filteredjobs = JobOffer.jobList.where((job) {
      return selectedCategoris.isEmpty || selectedCategoris.contains(job.title);
    }).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text("hey"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(0.8),
            margin: const EdgeInsets.all(0.8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,

              ///show all tags with the map creating FilterChips.
              children: categories
                  .map((category) => FilterChip(

                      ///initial that param of checking if it got selected.
                      selected: selectedCategoris.contains(category),
                      label: Text(category),

                      ///if selected. what now?
                      ///set state . for the next rebuild.updatnig the selected data.
                      ///adding or removing from list.
                      onSelected: (selected) {
                        setState(() {
                          if (selected) {
                            selectedCategoris.add(category);
                          } else {
                            selectedCategoris.remove(category);
                          }
                        });
                      }))
                  .toList(),
            ),
          ),
          Expanded(
            child: ListView.builder(

                ///final filteredjobs = JobOffer.jobList.where((job) {return selectedCategoris.isEmpty || selectedCategoris.contains(job.title);}).toList();
                ///thats the commant up there.
                ///to initialize the filtered list to show to the client.
                itemCount: filteredjobs.length,
                itemBuilder: (context, index) {
                  ///
                  final jo = filteredjobs[index];
                  return Card(
                    elevation: 8.0,
                    margin: const EdgeInsets.all(8.0),
                    child: Container(
                      decoration: BoxDecoration(color: Colors.indigoAccent),
                      child: ListTile(
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                        title: Text(
                          jo.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          jo.Job_description,
                          style: const TextStyle(
                              color: Colors.white, fontStyle: FontStyle.italic),
                        ),
                      ),
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }
}
 */
