/*
import 'dart:convert';

import 'package:gsheets/gsheets.dart';
import 'package:flutter/material.dart';
import 'package:trying_real_project_from_video/DataBase/sheetColumn.dart';

import 'jobModel.dart';

class SheetsFlutter {
  static const String _sheetsId =
      '1AfAlu3wLNrCYxhYgipydxS2GvpQvlZ7J82qI4AkNIMg';
  static const _sheetCredentials = r'''{
  "type": "service_account",
  "project_id": "analog-decoder-387917",

  "private_key_id": "32a9277fe336ef790a5f24a5439143069e591c41",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCY/y05m5qZcsG1\nbjx0LCEapyfnvWls3d38Gi+mb5jkouM0CDbIwEoceGxuKq+il5yqKi1nD3AR2tZW\nrAX5yHbZO8ia/9ypRezn00fsYDCoTs1xGBnUcJnSkQagIDASXxYTADrTYVhiDWsI\nbUHpZl3K7D96uJKDgVw5OaO/X+vAJ/ZhAIPQuKnmpU5s0EuEIM/buGHpx5p7/JHr\nAfX9Kh46fN5oHb489GaKAK4Q3w+Teks1O0yhUjbdAVg+rdwj3plD/1w2RHmwAHKq\nP8NgSlwIGgcy3mwuXPUtQQQK3+HyG2MSLfrS3Hh7vszV6LPjNCAR+IkAe6wGiTb4\nfDkjpJ6DAgMBAAECggEAEaO6Dx5FoNN+SfC/v5Um6+/BxhIsiYS7B0ntnH7ZXeL5\n1xHrXxHseYPY3IrHXTOluGjMe0loXmagt7V1qurV6Q3ffx9ozYtmWQQfEr20XnNX\ndGaW88tXsNNPtD6BzFxyKxansZ9TlVp+sKYIJ2TKA49hckC9g7PychaXLoVcpPbI\n5jj+3krZ3IHggwrJk+fWIcrXRT++paYLls99OBQQW9bYUfTBXukTa3q86ecsKKrD\nN9gcoFB8n+ERw+Iy6jLyA72U0cT4XeQE4cH0jWVfgwvyy/nx3jkrPgw82vID+j44\neUQVWCVGRkW26Ht+Kp1Us2LtyN7SiX+dVKVx/aA4QQKBgQDLXWHR8ImSqSkrxCOm\n9Q4+/OD59mBT2gkJVNXB8PeFo0lCgV4ncAgyEMOwTi2zIfj4Um5rHOAdpmO78nDt\nCnuwMhIAEDZzZ635LsLradCRTz5pYPlERjSvTpgv7JIBJQadwSpUgjeH4Kqfwzfl\nkIinst6sKIE7iFgF35tr5nqSaQKBgQDAmH5nXPDhmG28Tx5TBO2ikY+t4Ha6l34h\nSk/YLcN0I35GoZiU6hzHOXhWGUnAvBQY7hJAgOJp+MKwDTjGBc7p7XxQ7CBiEbGm\n9Rb9Hh5IvilX5LUeaieuYiIFnINPYLmbupELrWND94E7F8JVgH46r1ee6suRr1BE\nD7RC5ys0CwKBgQCVqQViIOi9m+wGn3O1XMa9KBDRI7XEP8NCsMIW1iTynjY90ULf\nNx1w6tF4oDAVkjzNUqyb+0Yby+W93S+p4nsgMdj5XvUTfQuVRAqCgP7S0USW/Jy0\n2A3Rrb9mFW1llkAGPK/QPXxsbLRkmqA6O2G2OHaSr8RbcX2F5QdWIum1cQKBgQC+\n8zJ4JsTI1wkNp9/n7b3x7aHngeIVc/fg572sFwtvTXV4b+VI16i6ubceninqhk7i\nvL+p5l8VNEdKp4E/jCiu8//Kd6JPuT1KzDsDsGXUN33kH+SXCCbZlYAn0hq6i6ra\nxKnkSv9dNrqRLShG/4OniYs1C5PTmF7bbDqMDoheKwKBgHftMYLVosMnkXu1SHBk\n3RXDBumk5W4DO9hZL6MDVyDW3aIJ6tISVwpci9ci5cwv6cr4cuk8YQvYWeDwVrEC\nCRtVrpczNbyJUgDS7K6JA51Q14iC/4qg6iDhDnBtJoC/LoiHI6KCcjq0IvM6we/v\nfGi0O63HQYpGWgkc4Fr5KC9f\n-----END PRIVATE KEY-----\n",
  "client_email": "flutterdatabase@analog-decoder-387917.iam.gserviceaccount.com",
  "client_id": "116517167729224016506",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/flutterdatabase%40analog-decoder-387917.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}''';
  static Worksheet? _userSheet;
  static final _gsheets = GSheets(_sheetCredentials);
  static Future init() async {
    try {
      final spreadsheet = await _gsheets.spreadsheet(_sheetsId);

      ///title here needs to be the name of the sheet page
      _userSheet = await _getWorkSheet(spreadsheet, title: "feedOfData");
      final firstRowJobs = SheetsColumnForJob.getColumnForJobs();
      _userSheet!.values.insertRow(1, firstRowJobs);

      //final firstRow = SheetsColumn.getColumn();
      //_userSheet!.values.insertRow(1, firstRow);
      ///insertUsers();
    } catch (e) {
      print(e);
    }
  }

  static Future insertUsers() async {
    final users = [
      User(
          name: 'dori',
          last: 'rozen',
          email: 'dori@gmail.com',
          location: 'מרכז',
          education: 'student',
          phoneNum: '0546396968',
          skills: '[1,6]',
          theIcon: 'icon3.png',
          password: '1'),
      User(
          name: 'alon',
          last: 'rozen',
          email: 'alon@gmail.com',
          location: 'דרום',
          education: 'student',
          phoneNum: '0546616688',
          skills: '[1,2]',
          theIcon: 'icon5.png',
          password: '1'),
      User(
          name: 'ofira',
          last: 'rozen',
          email: 'ofira@gmail.com',
          location: 'מרכז',
          education: 'student',
          phoneNum: '05246186661',
          skills: '[1,6,7]',
          theIcon: 'icon2.png',
          password: '1'),
      User(
          name: 'ido',
          last: 'ronen',
          email: 'ido@gmail.com',
          location: 'השפלה',
          education: 'student',
          phoneNum: '05464646474',
          skills: '[4,10]',
          theIcon: 'icon6.png',
          password: '1'),
      User(
          name: 'rom',
          last: 'gat',
          email: 'rom@gmail.com',
          location: 'מרכז',
          education: 'student',
          phoneNum: '0671371373',
          skills: '[2,3]',
          theIcon: 'icon1.png',
          password: '1')
    ];
    final JobsOffers = [
      JobOffer(
          title: "python",
          Job_location: "מרכז",
          job_type: "Part-time",
          Job_description:
              "We are looking for a detail-oriented marketing coordinator to assist with various marketing campaigns and initiatives. The ideal candidate should have strong communication skills and be familiar with social media platforms and analytics tools.",
          Job_requirements:
              "Bachelor's degree in Marketing or related field, Excellent written and verbal communication skills, Proficiency in social media management, Familiarity with Google Analytics"),
      JobOffer(
          title: "Data Scientist",
          Job_location: "השפלה",
          job_type: "Full-time",
          Job_description:
              "We are seeking a motivated sales representative to drive sales and build relationships with potential clients. The ideal candidate should have a proven track record in sales and excellent interpersonal skills.",
          Job_requirements:
              "Minimum of 2 years of sales experience, Strong negotiation and communication skills, Self-motivated and target-driven"),
      JobOffer(
          title: "machine learning",
          Job_location: "מרכז",
          job_type: "Freelance",
          Job_description:
              "We are looking for a creative and talented graphic designer to create visually appealing designs for various projects. The ideal candidate should have a strong portfolio showcasing their design skills and proficiency in design software.",
          Job_requirements:
              "Bachelor's degree in Graphic Design or related field, Proficiency in Adobe Creative Suite, Strong portfolio demonstrating design abilities"),
      JobOffer(
          title: "java",
          Job_location: "ירושלים",
          job_type: "Full-time",
          Job_description:
              "We are seeking a detail-oriented financial analyst to provide financial analysis and reporting for our organization. The ideal candidate should have strong analytical skills and be proficient in financial modeling and data analysis tools.",
          Job_requirements:
              "Bachelor's degree in Finance or related field, Strong analytical and problem-solving skills, Proficiency in Microsoft Excel and financial modeling"),
      JobOffer(
          title: "python",
          Job_location: "מרכז",
          job_type: "Full-time",
          Job_description:
              "We are looking for a friendly and customer-focused representative to handle customer inquiries and resolve issues. The ideal candidate should have excellent communication skills and the ability to work in a fast-paced environment.",
          Job_requirements:
              "Excellent verbal and written communication skills, Strong problem-solving abilities, Previous customer service experience is a plus"),
      JobOffer(
          title: "Data Scientist",
          Job_location: "דרום",
          job_type: "Full-time",
          Job_description:
              "We are seeking a skilled data scientist to analyze large datasets and generate valuable insights for our organization. The ideal candidate should have a strong background in statistics and machine learning.",
          Job_requirements:
              "Master's degree or higher in Data Science or related field, Proficiency in programming languages such as Python or R, Experience with statistical analysis and machine learning techniques"),
      JobOffer(
          title: "C++",
          Job_location: "מרכז",
          job_type: "Full-time",
          Job_description:
              "We are looking for an experienced HR manager to oversee our HR operations and support the organization's strategic goals. The ideal candidate should have a strong knowledge of HR policies and procedures.",
          Job_requirements:
              "Bachelor's degree in Human Resources or related field, Minimum of 5 years of HR management experience, In-depth understanding of labor laws and regulations"),
    ];

    final jsonJobsOffers =
        JobsOffers.map((JobOffer) => JobOffer.toJson()).toList();
    await SheetsFlutter.insert(jsonJobsOffers);
  }

  static Future<Worksheet?> _getWorkSheet(
    Spreadsheet spreadsheet, {
    required String title,
  }) async {
    try {
      return await spreadsheet.addWorksheet(title);
    } catch (e) {
      return spreadsheet.worksheetByTitle(title);
    }
  }

  static Future insert(List<Map<String, dynamic>> rowList) async {
    _userSheet!.values.map.appendRows(rowList);
  }

  static Future<User?> getByEmail(String email) async {
    if (_userSheet == null) return null;
    final json = await _userSheet!.values.map.rowByKey(email, fromColumn: 1);
    print(json);
    return json == null ? null : User.fromJson(json);
  }

  static Future<List<User>> getAll() async {
    if (_userSheet == null) return <User>[];
    final users = await _userSheet!.values.map.allRows();
    return users == null ? <User>[] : users.map(User.fromJson).toList();
  }
}
 */
