import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:trying_real_project_from_video/DataBase/googlesheets.dart';
import 'package:trying_real_project_from_video/DataBase/sheetColumn.dart';
import 'package:trying_real_project_from_video/String_file/text_string.dart';
import 'package:trying_real_project_from_video/login_pages/loginPage.dart';
import '../String_file/image_string.dart';
import '../themes/theme_helper.dart';
import '../widgets/header_widget.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';

RegistrationForm theAvatar = RegistrationForm();

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  State<StatefulWidget> createState() {
    return _RegistrationPageState();
  }
}

class _RegistrationPageState extends State<RegistrationPage> {
  final _formKey = GlobalKey<FormState>();
  bool checkboxValue = false;
  TextEditingController nameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneNumController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  dynamic _selectedEducation;
  dynamic _selectedLocation;
  String? selectedIcon;

  List<Object?> skillsSelected = [];
  List<String> _educationList = [
    'High School',
    'Bachelor\'s Degree',
    'Master\'s Degree',
    'Doctorate Degree',
    'student'
  ];
  List<String> _locationList = [
    'צפון',
    'מרכז',
    'דרום',
    'השרון',
    'ירושלים',
    'השפלה'
  ];
  final _items = [
    for (int i = 1; i <= 10; i++)
      MultiSelectItem(
          i,
          '${[
            'java',
            'python',
            'c++',
            'c',
            'dart',
            'full stack',
            'frontend',
            'backend',
            'machine learning',
            'deep learning'
          ][i - 1]}'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Container(
              height: 150,
              child: HeaderWidget(150, false, Icons.person_add_alt_1_rounded),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(25, 50, 25, 10),
              padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
              alignment: Alignment.center,
              child: Column(
                children: [
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        GestureDetector(
                          child: Stack(
                            children: [
                              Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  border:
                                      Border.all(width: 5, color: Colors.white),
                                  color: Colors.white,
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 20,
                                      offset: Offset(5, 5),
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  Icons.person,
                                  color: Colors.grey.shade300,
                                  size: 80.0,
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.fromLTRB(80, 80, 0, 0),
                                child: Icon(
                                  Icons.add_circle,
                                  color: Colors.grey.shade700,
                                  size: 25.0,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        theAvatar,
                        SizedBox(height: 20),
                        Container(
                          decoration: ThemeHelper().inputBoxDecorationShaddow(),
                          child: TextFormField(
                            controller: nameController,
                            /*onChanged:(value)=>thet = value,*/
                            decoration: ThemeHelper().textInputDecoration(
                                'First Name', 'Enter your first name'),
                            /*onSaved: (value) => name = value,*/
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          decoration: ThemeHelper().inputBoxDecorationShaddow(),
                          child: TextFormField(
                            controller: lastNameController,
                            decoration: ThemeHelper().textInputDecoration(
                                'Last Name', 'Enter your last name'),
                            //onSaved: (value) => lastName = value,
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          decoration: ThemeHelper().inputBoxDecorationShaddow(),
                          child: TextFormField(
                              controller: emailController,
                              obscureText: false,
                              decoration: ThemeHelper().textInputDecoration(
                                  "E-mail address", "Enter your email"),
                              keyboardType: TextInputType.emailAddress,
                              validator: (val) {
                                if ((val!.isNotEmpty) &&
                                    !RegExp(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}"
                                            r"[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?)*$"!)
                                        .hasMatch(val)) {
                                  return "Enter a valid E-mail address";
                                }
                                return null;
                              }),
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          decoration: ThemeHelper().inputBoxDecorationShaddow(),
                          child: TextFormField(
                              controller: phoneNumController,
                              obscureText: false,
                              decoration: ThemeHelper().textInputDecoration(
                                  "Mobile Number", "Enter your mobile number"),
                              keyboardType: TextInputType.phone,
                              validator: (val) {
                                if ((val!.isNotEmpty) &&
                                    !RegExp(r"^(\d+)*$").hasMatch(val)) {
                                  return "Enter a valid Mobile Number";
                                }
                                return null;
                              }),
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          decoration: ThemeHelper().inputBoxDecorationShaddow(),
                          child: TextFormField(
                            controller: passwordController,
                            obscureText: true,
                            decoration: ThemeHelper().textInputDecoration(
                                "Password*", "Enter your password"),
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "Please enter your password";
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          decoration: ThemeHelper().inputBoxDecorationShaddow(),
                          /*
                          DropdownButtonFormField<String>(
                            value: _selectedEducation,
                            decoration: InputDecoration(
                              labelText: 'Education',
                              border: OutlineInputBorder(),
                            ),
                            items: _educationList.map((education) {
                              return DropdownMenuItem(
                                value: education,
                                child: Text(education),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedEducation = value!;
                              });
                            },
                          ),
                        ),
                           */
                          child: MultiSelectBottomSheetField(
                            initialValue: skillsSelected,
                            initialChildSize: 0.4,
                            listType: MultiSelectListType.CHIP,
                            searchable: true,
                            buttonText: const Text('Select your skills'),
                            title: const Text('Options:'),
                            items: _items,
                            onConfirm: (values) {
                              setState(() {
                                skillsSelected = values;
                                print(skillsSelected.runtimeType.toString());
                              });
                            },
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          padding: const EdgeInsets.all(2.0),

                          ///Education
                          child: DropdownButtonFormField<String>(
                            value: _selectedEducation,
                            decoration: const InputDecoration(
                              labelText: 'Education',
                              border: OutlineInputBorder(),
                            ),
                            items: _educationList.map((education) {
                              return DropdownMenuItem(
                                value: education,
                                child: Text(education),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setState(() {
                                _selectedEducation = value!;
                                print(_selectedEducation);
                                print(
                                    _selectedEducation.runtimeType.toString());
                              });
                            },
                          ),
                        ),
                        const SizedBox(height: 15.0),
                        DropdownButtonFormField<String>(
                          value: _selectedLocation,
                          decoration: const InputDecoration(
                            labelText: 'Location',
                            border: OutlineInputBorder(),
                          ),
                          items: _locationList.map((location) {
                            return DropdownMenuItem(
                              value: location,
                              child: Text(location),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedLocation = value!;
                              print(_selectedLocation);
                              print(_selectedLocation.runtimeType.toString());
                            });
                          },
                        ),
                        const SizedBox(height: 15.0),

                        ///accepting box
                        FormField<bool>(
                          builder: (state) {
                            return Column(
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Checkbox(
                                        value: checkboxValue,
                                        onChanged: (value) {
                                          setState(() {
                                            checkboxValue = value!;
                                            state.didChange(value);
                                          });
                                        }),
                                    const Text(
                                      "I accept all terms and conditions.",
                                      style: TextStyle(color: Colors.grey),
                                    ),
                                  ],
                                ),
                                Container(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    state.errorText ?? '',
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: Theme.of(context).errorColor,
                                      fontSize: 12,
                                    ),
                                  ),
                                )
                              ],
                            );
                          },
                          validator: (value) {
                            if (!checkboxValue) {
                              return 'You need to accept terms and conditions';
                            } else {
                              return null;
                            }
                          },
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          decoration:
                              ThemeHelper().buttonBoxDecoration(context),
                          child: ElevatedButton(
                            style: ThemeHelper().buttonStyle(),
                            child: Padding(
                              padding:
                                  const EdgeInsets.fromLTRB(40, 10, 40, 10),
                              child: Text(
                                "Register".toUpperCase(),
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            onPressed: () async {
                              var uname = nameController.text;
                              var ulastname = lastNameController.text;
                              var upassword = passwordController.text;
                              var uphone = phoneNumController.text;
                              var uemail = emailController.text;
                              var ueducaiton = _selectedEducation;
                              var ulocation = _selectedLocation;
                              String? theIcon = theAvatar.selectedAvatar;
                              if (_formKey.currentState!.validate()) {
                                /*
                                final feedBack = User(
                                  name: nameController.text,
                                  last: lastNameController.text,
                                  email: emailController.text,
                                  password: passwordController.text,
                                  phoneNum: phoneNumController.text,
                                  skills: skillsSelected.toString(),
                                  location: _selectedLocation.toString(),
                                  theIcon: theIcon.toString(),
                                  education: _selectedEducation.toString(),
                                );
                                 */
                                //await SheetsFlutter.insert([feedBack.toJson()]);

                                Navigator.of(context).pushAndRemoveUntil(
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const LoginPage()),
                                    (Route<dynamic> route) => false);
                              }
                            },
                          ),
                        ),
                        SizedBox(height: 30.0.h),
                        const Text(
                          "Or create account using social media",
                          style: TextStyle(color: Colors.grey),
                        ),
                        SizedBox(height: 25.0.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              child: FaIcon(
                                FontAwesomeIcons.googlePlus,
                                size: 35,
                                color: HexColor("#EC2D2F"),
                              ),
                              onTap: () {
                                setState(() {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return ThemeHelper().alartDialog(
                                          "Google Plus",
                                          "You tap on GooglePlus social icon.",
                                          context);
                                    },
                                  );
                                });
                              },
                            ),
                            SizedBox(
                              width: 30.0.w,
                            ),
                            GestureDetector(
                              child: Container(
                                padding: EdgeInsets.all(2.0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  border: Border.all(
                                      width: 5, color: HexColor("#40ABF0")),
                                  color: HexColor("#40ABF0"),
                                ),
                                child: FaIcon(
                                  FontAwesomeIcons.twitter,
                                  size: 23,
                                  color: HexColor("#FFFFFF"),
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return ThemeHelper().alartDialog(
                                          "Twitter",
                                          "You tap on Twitter social icon.",
                                          context);
                                    },
                                  );
                                });
                              },
                            ),
                            SizedBox(
                              width: 30.0,
                            ),
                            GestureDetector(
                              child: FaIcon(
                                FontAwesomeIcons.facebook,
                                size: 35,
                                color: HexColor("#3E529C"),
                              ),
                              onTap: () {
                                setState(() {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return ThemeHelper().alartDialog(
                                          "Facebook",
                                          "You tap on Facebook social icon.",
                                          context);
                                    },
                                  );
                                });
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/*
class ContainerTextField extends StatelessWidget {
  const ContainerTextField(
      {super.key,
      this.isobscureText,
      this.mainStr,
      this.secStr,
      this.inputType,
      this.valStr});
  final bool? isobscureText;
  final String? mainStr, secStr, valStr;
  final TextInputType? inputType;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: ThemeHelper().inputBoxDecorationShaddow(),
      child: TextFormField(
          obscureText: isobscureText!,
          decoration: ThemeHelper().textInputDecoration(mainStr!, secStr!),
          keyboardType: inputType,
          validator: (val) {
            if (isobscureText == true) {
              if (!(val!.isEmpty) && !RegExp(valStr!).hasMatch(val)) {
                return "Enter a valid $mainStr";
              }
            }
            return null;
          }),
    );
  }
}

 */

final avatarList = [for (int i = 1; i <= 11; i++) 'icon$i.png'];

class RegistrationForm extends StatefulWidget {
  RegistrationForm({super.key});
  String? selectedAvatar;

  String? getSelectedAvatar() {
    return selectedAvatar;
  }

  @override
  _RegistrationFormState createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  void _showAvatarChooser() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16),
          child: Wrap(
            spacing: 16,
            runSpacing: 16,
            children: avatarList
                .map((avatar) => GestureDetector(
                      onTap: () {
                        setState(() {
                          widget.selectedAvatar = avatar;
                        });
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: AssetImage(avatar),
                          ),
                        ),
                        child: widget.selectedAvatar == avatar
                            ? Icon(Icons.check_circle, color: Colors.white)
                            : null,
                      ),
                    ))
                .toList(),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Other form fields...
        SizedBox(height: 16),
        ElevatedButton(
          onPressed: _showAvatarChooser,
          child: Text('Choose Avatar'),
        ),
        SizedBox(height: 16),
        widget.selectedAvatar != null
            ? CircleAvatar(
                radius: 40,
                backgroundImage: AssetImage(widget.selectedAvatar!),
              )
            : SizedBox.shrink(),
        // Other form fields...
      ],
    );
  }
}
