import 'package:flutter/material.dart';
import 'package:trying_real_project_from_video/login_pages/loginPage.dart';

import '../DataBase/testingProjectOfAfgrommer.dart';

class User {
  String name, lastName, password, email, location, education, phoneNum;
  List<String?> skills;
  String? myIcon;

  User({
    required this.name,
    required this.email,
    required this.location,
    required this.lastName,
    required this.education,
    required this.phoneNum,
    required this.skills,
    required this.myIcon,
    required this.password,
  });
}

class HeroProfilePage extends StatelessWidget {
  final User user;

  const HeroProfilePage({Key? key, required this.user}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leadingWidth: 20,
        leading: IconButton(
          padding: EdgeInsets.only(left: 20),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AfPage(user: user),
              ),
            );
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.grey.shade600,
          ),
        ),
      ),
      body: Center(
        child: Hero(
          tag: '${user.name}${user.email}',
          child: CircleAvatar(
            radius: 120,
            backgroundColor: Colors.white,
            backgroundImage: AssetImage(user.myIcon ?? ''),
          ),
        ),
      ),
    );
  }
}

/*
List<User> allUsers = [];

class User {
  String? name, lastname, password, email, location, education, phoneNum;
  List<Object?> skills;
  String? myIcon;

  User(
      {required this.name,
      required this.email,
      required this.location,
      required this.lastname,
      required this.education,
      required this.phoneNum,
      required this.skills,
      required this.myIcon,
      required this.password});

  void setName(String name) {
    this.name = name;
  }

  void setEmail(String email) {
    this.email = email;
  }

  void setPassword(String password) {
    this.password = password;
  }

  void setIcon(String avatarIcon) {
    this.myIcon = avatarIcon;
  }

  String? getName() {
    return name;
  }

  String? getEmail() {
    return email;
  }

  String? getPassword() {
    return password;
  }

  String? getIcon() {
    return myIcon;
  }

  List<User> getUsers() {
    return allUsers;
  }
/*

  Map<String, dynamic> toJson() {
    return {
      'name': this.name,
      'email': this.email,
      'password': this.password,
      'myIcon': this.myIcon,
      'location': this.location,
      'age': this.age
    };
  }

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      name: json['name'],
      email: json['email'],
      password: json['password'],
      myIcon: json['myIcon'],
      location: json['location'],
      age: json['age'],
    );
  }
 */

  void addUser(User user) {
    allUsers.add(user);
  }

  void removeUser(User user) {
    allUsers.remove(user);
  }

  @override
  String toString() {
    return "User(name: $name, lastname: $lastname,"
        " password: $password, email: $email, "
        "location: $location, education: $education,"
        " phoneNum: $phoneNum, skills: $skills, myIcon: $myIcon)";
  }
}

String? name, lastname, password, email, location, education, phoneNum;
  List<Object?> skills;
  Icon? myIcon;
 */
