String loginUrlImage =
    'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80';
String signUpUrlImage =
    'https://images.pexels.com/photos/443383/pexels-photo-443383.jpeg';
