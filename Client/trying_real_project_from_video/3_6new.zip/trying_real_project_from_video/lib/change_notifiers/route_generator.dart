import 'package:flutter/material.dart';
import 'package:trying_real_project_from_video/Starting_Pages/splashWelcomePage.dart';
import '../Starting_Pages/onbording_screen.dart';
import '../Starting_Pages/splash_screen.dart';
import '../login_pages/forgot_password_page.dart';
import '../login_pages/forgot_password_verification_page.dart';
import '../login_pages/loginPage.dart';
import '../login_pages/registration_page.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    // Getting arguments passed in while calling Navigator.pushNamed
    final args = settings.arguments;
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => Splash()); //SplashScreenOne
      case '/SplashScreenOne':
        return MaterialPageRoute(builder: (_) => SplashScreenOne());
      case '/SwitchPageStart':
        return MaterialPageRoute(builder: (_) => SwitchPageStart());
      case '/LoginPage':
        return MaterialPageRoute(builder: (_) => LoginPage());
      case '/RegistrationPage':
        // Validation of correct data type
        //if (args is String) {
        return MaterialPageRoute(
          builder: (_) => RegistrationPage(/*data: args,*/),
        );
      case '/ForgotPasswordPage':
        return MaterialPageRoute(builder: (_) => ForgotPasswordPage());
      case '/ForgotPasswordVerificationPage':
        return MaterialPageRoute(
            builder: (_) => ForgotPasswordVerificationPage());

        //}
        // If args is not of the correct type, return an error page.
        // You can also throw an exception while in development.
        return _errorRoute();
      default:
        // If there is no such named route in the switch statement, e.g. /third
        return _errorRoute();
    }
  }

  static Route<dynamic> _errorRoute() {
    return MaterialPageRoute(builder: (_) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Error'),
        ),
        body: Center(
          child: Text('ERROR'),
        ),
      );
    });
  }
}
